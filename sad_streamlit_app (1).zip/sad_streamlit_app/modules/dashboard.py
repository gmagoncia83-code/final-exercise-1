"""Decision-support dashboard: KPIs, risk/review queue, follow-up guidance."""
import pandas as pd

from modules.data_processing import FEATURES, TARGET, labeled_subset
from modules.prediction import risk_level

FOLLOW_UP = {
    "High": "Assign to a staff member today, confirm documents are complete, "
            "and notify the requester of the expected timeline.",
    "Medium": "Monitor daily; check document completeness and office workload.",
    "Low": "Process through the normal queue.",
}


def kpis(df):
    lab = labeled_subset(df)
    return {
        "Total requests": int(len(df)),
        "Completed": int((df["Status"] == "Completed").sum()),
        "Open (pending)": int((df["Status"] == "Pending").sum()),
        "SLA breach rate": f"{lab[TARGET].mean() * 100:.1f}%" if len(lab) else "n/a",
        "Avg queue length": f"{df['Queue_Length'].mean():.1f}",
        "Avg processing days": f"{lab['Processing_Days'].mean():.1f}" if len(lab) else "n/a",
    }


def score_requests(df, pipe):
    """Score every request using submission-time features only."""
    scored = df.copy()
    scored["Breach_Probability"] = pipe.predict_proba(scored[FEATURES])[:, list(pipe.classes_).index(1)]
    scored["Risk_Level"] = scored["Breach_Probability"].apply(risk_level)
    scored["Recommended_Follow_Up"] = scored["Risk_Level"].map(FOLLOW_UP)
    return scored


def review_queue(scored, threshold=0.5):
    """Open requests at or above the threshold, highest risk first."""
    q = scored[(scored["Status"] == "Pending") & (scored["Breach_Probability"] >= threshold)]
    cols = ["Request_ID", "Service_Type", "Assigned_Office", "Priority", "Queue_Length",
            "Required_Documents_Complete", "Breach_Probability", "Risk_Level",
            "Recommended_Follow_Up"]
    return q.sort_values("Breach_Probability", ascending=False)[cols].reset_index(drop=True)


def office_workload(df):
    g = df.groupby("Assigned_Office").agg(
        Requests=("Request_ID", "count"),
        Open=("Status", lambda s: int((s == "Pending").sum())),
        Avg_Queue=("Queue_Length", "mean"),
    ).round(1).reset_index()
    return g
