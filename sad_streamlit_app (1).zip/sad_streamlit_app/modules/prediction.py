"""Model training (one-time), loading and inference.

The model is trained ONCE by train_model.py and saved with joblib. The app only
loads it (see load_model in app.py) - it never retrains on page refresh.
"""
import json
import datetime as dt
from pathlib import Path

import joblib
import numpy as np
import pandas as pd
import sklearn
from sklearn.compose import ColumnTransformer
from sklearn.dummy import DummyClassifier
from sklearn.metrics import (accuracy_score, confusion_matrix, f1_score,
                             precision_score, recall_score)
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder
from sklearn.tree import DecisionTreeClassifier

from modules.data_processing import (CAT_FEATURES, FEATURES, NUM_FEATURES,
                                     TARGET, labeled_subset, prepare,
                                     queue_category, split_data)

BASE_DIR = Path(__file__).resolve().parent.parent
MODEL_PATH = BASE_DIR / "models" / "trained_model.joblib"
META_PATH = BASE_DIR / "models" / "model_metadata.json"
DATA_PATH = BASE_DIR / "data" / "student_service_requests.csv"

MODEL_VERSION = "1.0.0"
LIMITATIONS = [
    "Trained on a small, synthetic/historical dataset; accuracy on real requests may differ.",
    "Uses submission-time information only; it cannot see later events (reopening, staff absence).",
    "A Decision Tree gives coarse probabilities; treat them as risk levels, not guarantees.",
    "Missing or inconsistent inputs lower reliability; verify the request details first.",
    "Output is decision support only. Authorized staff make the final decision.",
]


def build_pipeline():
    pre = ColumnTransformer([
        ("cat", OneHotEncoder(handle_unknown="ignore"), CAT_FEATURES),
        ("num", "passthrough", NUM_FEATURES),
    ])
    return Pipeline([
        ("prep", pre),
        ("clf", DecisionTreeClassifier(max_depth=5, min_samples_leaf=5,
                                       random_state=42)),
    ])


def _feature_importance(pipe):
    names = pipe.named_steps["prep"].get_feature_names_out()
    imps = pipe.named_steps["clf"].feature_importances_
    agg = {f: 0.0 for f in FEATURES}
    for name, imp in zip(names, imps):
        raw = name.split("__", 1)[1]
        for f in FEATURES:
            if raw == f or raw.startswith(f + "_"):
                agg[f] += float(imp)
                break
    return dict(sorted(agg.items(), key=lambda kv: kv[1], reverse=True))


def evaluate(pipe, X_test, y_test):
    pred = pipe.predict(X_test)
    base = DummyClassifier(strategy="most_frequent").fit(X_test, y_test)
    bpred = base.predict(X_test)
    cm = confusion_matrix(y_test, pred, labels=[0, 1])
    return {
        "accuracy": float(accuracy_score(y_test, pred)),
        "precision": float(precision_score(y_test, pred, pos_label=1, zero_division=0)),
        "recall": float(recall_score(y_test, pred, pos_label=1, zero_division=0)),
        "f1": float(f1_score(y_test, pred, pos_label=1, zero_division=0)),
        "baseline_accuracy": float(accuracy_score(y_test, bpred)),
        "confusion_matrix": cm.tolist(),
        "test_size": int(len(y_test)),
    }


def train_and_save(csv_path=DATA_PATH):
    """Train the Decision Tree and save pipeline + metadata. Run once."""
    raw = pd.read_csv(csv_path)
    df, _ = prepare(raw)
    lab = labeled_subset(df)
    X_train, X_test, y_train, y_test = split_data(lab)
    pipe = build_pipeline().fit(X_train, y_train)
    meta = {
        "model_version": MODEL_VERSION,
        "trained_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
        "sklearn_version": sklearn.__version__,
        "algorithm": "DecisionTreeClassifier(max_depth=5, min_samples_leaf=5, random_state=42)",
        "target": TARGET,
        "features": FEATURES,
        "train_rows": int(len(X_train)),
        "metrics": evaluate(pipe, X_test, y_test),
        "feature_importance": _feature_importance(pipe),
        "categories": {c: sorted(lab[c].dropna().unique().tolist()) for c in CAT_FEATURES},
        "numeric_ranges": {c: [float(lab[c].min()), float(lab[c].max())] for c in NUM_FEATURES},
    }
    MODEL_PATH.parent.mkdir(exist_ok=True)
    joblib.dump(pipe, MODEL_PATH)
    META_PATH.write_text(json.dumps(meta, indent=2))
    return pipe, meta


def load_artifacts():
    """Load saved model + metadata. Falls back to a one-time retrain if the
    joblib file is missing or was built with an incompatible scikit-learn."""
    try:
        pipe = joblib.load(MODEL_PATH)
        meta = json.loads(META_PATH.read_text())
        pipe.predict(pd.DataFrame([{f: (0 if f in NUM_FEATURES else meta["categories"][f][0])
                                    for f in FEATURES}]))
        return pipe, meta
    except Exception:
        return train_and_save()


def build_input_row(service_type, requester_type, channel, priority, office,
                    docs_complete, queue_length, sla_days, submission_date):
    """One-row DataFrame with the exact training feature names and types."""
    ts = pd.Timestamp(submission_date)
    row = {
        "Service_Type": service_type,
        "Requester_Type": requester_type,
        "Requested_Channel": channel,
        "Priority": priority,
        "Assigned_Office": office,
        "Required_Documents_Complete": docs_complete,
        "Submission_Weekday": ts.day_name(),
        "Queue_Category": queue_category(queue_length),
        "Queue_Length": int(queue_length),
        "SLA_Days": int(sla_days),
    }
    return pd.DataFrame([row], columns=FEATURES)


def risk_level(p):
    if p >= 0.7:
        return "High"
    if p >= 0.4:
        return "Medium"
    return "Low"


def predict_one(pipe, row):
    label = int(pipe.predict(row)[0])
    proba = None
    if hasattr(pipe, "predict_proba"):
        proba = float(pipe.predict_proba(row)[0][list(pipe.classes_).index(1)])
    return {
        "label": label,
        "probability": proba,
        "risk": risk_level(proba) if proba is not None else None,
        "timestamp": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
    }


def verify_consistency(pipe, meta, df_featured):
    """Recompute metrics on the same 80/20 split (random_state=42) and compare
    them with the metrics saved at training time (midterm consistency check)."""
    lab = labeled_subset(df_featured)
    _, X_test, _, y_test = split_data(lab)
    now = evaluate(pipe, X_test, y_test)
    saved = meta["metrics"]
    keys = ["accuracy", "precision", "recall", "f1"]
    rows = [{"Metric": k.title(), "Saved (midterm run)": round(saved[k], 3),
             "Recomputed now": round(now[k], 3),
             "Match": abs(saved[k] - now[k]) < 1e-9} for k in keys]
    return pd.DataFrame(rows)
