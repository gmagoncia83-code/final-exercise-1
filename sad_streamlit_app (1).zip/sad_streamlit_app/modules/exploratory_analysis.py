"""EDA helpers: descriptive statistics and interactive Plotly charts."""
import pandas as pd
import plotly.express as px

from modules.data_processing import TARGET, labeled_subset


def descriptive_stats(df):
    return df.describe(include="all").T.astype(str)


def class_distribution(df):
    lab = labeled_subset(df)
    counts = lab[TARGET].map({0: "Met SLA (0)", 1: "Breached (1)"}).value_counts()
    return counts.rename_axis("Class").reset_index(name="Count")


def fig_class_distribution(df):
    cd = class_distribution(df)
    return px.pie(cd, names="Class", values="Count", hole=0.4,
                  title="SLA outcome (completed requests)")


def fig_requests_by_service(df):
    c = df["Service_Type"].value_counts().rename_axis("Service_Type").reset_index(name="Requests")
    return px.bar(c, x="Service_Type", y="Requests", color="Service_Type",
                  title="Request volume by service type")


def breach_rate_by(df, col):
    lab = labeled_subset(df)
    g = lab.groupby(col)[TARGET].agg(["mean", "count"]).reset_index()
    g["Breach_Rate_%"] = (g["mean"] * 100).round(1)
    return g.rename(columns={"count": "Completed"}).drop(columns="mean")


def fig_breach_by_office(df):
    g = breach_rate_by(df, "Assigned_Office")
    return px.bar(g, x="Assigned_Office", y="Breach_Rate_%", color="Assigned_Office",
                  hover_data=["Completed"], title="SLA breach rate by office")


def fig_breach_by_queue(df):
    g = breach_rate_by(df, "Queue_Category")
    order = ["Low", "Medium", "High"]
    g["Queue_Category"] = pd.Categorical(g["Queue_Category"], order, ordered=True)
    g = g.sort_values("Queue_Category")
    return px.bar(g, x="Queue_Category", y="Breach_Rate_%", color="Queue_Category",
                  hover_data=["Completed"], title="Breach rate by queue category")


def fig_breach_by_weekday_channel(df):
    lab = labeled_subset(df)
    g = lab.groupby(["Requested_Channel", "Priority"])[TARGET].mean().mul(100).round(1)
    g = g.reset_index(name="Breach_Rate_%")
    return px.bar(g, x="Requested_Channel", y="Breach_Rate_%", color="Priority",
                  barmode="group", title="Breach rate by channel and priority")


def fig_monthly_volume(df):
    m = df.copy()
    m["Month"] = m["Submission_Date"].dt.to_period("M").astype(str)
    g = m.groupby("Month").size().reset_index(name="Requests")
    return px.line(g, x="Month", y="Requests", markers=True,
                   title="Monthly request volume")
