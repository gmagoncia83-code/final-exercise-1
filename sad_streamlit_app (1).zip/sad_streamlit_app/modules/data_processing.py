"""Data loading, validation, cleaning and feature engineering.

Mirrors the midterm laboratory (Part I-II): same schema, same cleaning rules,
same engineered features and the same SLA_Breached target definition.
"""
import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split

REQUIRED_COLUMNS = [
    "Request_ID", "Service_Type", "Requester_Type", "Submission_Date",
    "Requested_Channel", "Priority", "Assigned_Office", "Queue_Length",
    "Required_Documents_Complete", "Processing_Days", "SLA_Days", "Status",
    "Reopened", "Satisfaction_Score",
]

# Submission-time features ONLY. Processing_Days, Status, Reopened and
# Satisfaction_Score are leakage variables and are never used for prediction.
CAT_FEATURES = [
    "Service_Type", "Requester_Type", "Requested_Channel", "Priority",
    "Assigned_Office", "Required_Documents_Complete", "Submission_Weekday",
    "Queue_Category",
]
NUM_FEATURES = ["Queue_Length", "SLA_Days"]
FEATURES = CAT_FEATURES + NUM_FEATURES
LEAKAGE_COLUMNS = ["Processing_Days", "Status", "Reopened", "Satisfaction_Score"]
TARGET = "SLA_Breached"

CANONICAL = {
    "Requested_Channel": ["Portal", "Email", "Walk-in"],
    "Priority": ["Low", "Normal", "High"],
    "Requester_Type": ["Student", "Faculty", "Staff"],
    "Status": ["Completed", "Pending", "Cancelled"],
    "Required_Documents_Complete": ["Yes", "No"],
    "Reopened": ["Yes", "No"],
    "Service_Type": ["Records", "Certification", "IT Support",
                     "Scholarship Inquiry", "Clearance"],
}


def queue_category(n):
    """Low: 0-5, Medium: 6-15, High: >15 (midterm definition)."""
    if pd.isna(n):
        return np.nan
    if n <= 5:
        return "Low"
    if n <= 15:
        return "Medium"
    return "High"


def validate_schema(df):
    """Return (is_valid, missing_columns, extra_columns)."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    extra = [c for c in df.columns if c not in REQUIRED_COLUMNS]
    return len(missing) == 0, missing, extra


def quality_summary(df):
    """Null and duplicate summary for the raw upload."""
    nulls = df.isna().sum().rename("Null_Count").to_frame()
    nulls["Null_%"] = (nulls["Null_Count"] / max(len(df), 1) * 100).round(1)
    dup_ids = int(df["Request_ID"].duplicated().sum()) if "Request_ID" in df else 0
    return {
        "rows": len(df),
        "columns": df.shape[1],
        "duplicate_rows": int(df.duplicated().sum()),
        "duplicate_ids": dup_ids,
        "nulls": nulls,
    }


def _canonicalize(series, allowed):
    lookup = {a.lower(): a for a in allowed}
    cleaned = series.astype("string").str.strip()
    mapped = cleaned.str.lower().map(lookup)
    return mapped.fillna(cleaned).astype(object)


def clean_data(df):
    """Apply the midterm cleaning rules. Returns (clean_df, log_list)."""
    log = []
    out = df.copy()
    start = len(out)

    for col in out.columns:
        if out[col].dtype == object or str(out[col].dtype) == "string":
            out[col] = out[col].astype("string").str.strip().astype(object)

    for col, allowed in CANONICAL.items():
        if col in out:
            before = out[col].nunique(dropna=True)
            out[col] = _canonicalize(out[col], allowed)
            after = out[col].nunique(dropna=True)
            if before != after:
                log.append(f"Standardized inconsistent categories in {col} "
                           f"({before} -> {after} distinct values).")

    dups = int(out["Request_ID"].duplicated().sum())
    if dups:
        out = out.drop_duplicates(subset="Request_ID", keep="first")
        log.append(f"Removed {dups} duplicate Request_ID row(s) (kept first).")

    out["Submission_Date"] = pd.to_datetime(out["Submission_Date"], errors="coerce")
    bad_dates = int(out["Submission_Date"].isna().sum())
    if bad_dates:
        out = out[out["Submission_Date"].notna()]
        log.append(f"Dropped {bad_dates} row(s) with invalid Submission_Date.")

    for col in ["Queue_Length", "SLA_Days", "Processing_Days", "Satisfaction_Score"]:
        out[col] = pd.to_numeric(out[col], errors="coerce")

    bad = (out["Queue_Length"] < 0) | (out["SLA_Days"] <= 0)
    if bad.sum():
        log.append(f"Dropped {int(bad.sum())} row(s) with negative Queue_Length "
                   f"or non-positive SLA_Days.")
        out = out[~bad]
    neg_p = out["Processing_Days"] < 0
    if neg_p.sum():
        out.loc[neg_p, "Processing_Days"] = np.nan
        log.append(f"Set {int(neg_p.sum())} negative Processing_Days value(s) to missing.")

    miss = out[["Queue_Length", "SLA_Days"]].isna().any(axis=1)
    if miss.sum():
        out = out[~miss]
        log.append(f"Dropped {int(miss.sum())} row(s) with missing Queue_Length / SLA_Days.")

    log.append(f"Rows: {start} -> {len(out)} after cleaning.")
    return out.reset_index(drop=True), log


def add_features(df):
    """Create Submission_Weekday, Queue_Category and SLA_Breached."""
    out = df.copy()
    out["Submission_Weekday"] = out["Submission_Date"].dt.day_name()
    out["Queue_Category"] = out["Queue_Length"].apply(queue_category)
    eligible = (out["Status"] == "Completed") & out["Processing_Days"].notna() \
        & out["SLA_Days"].notna()
    out[TARGET] = np.where(
        eligible, (out["Processing_Days"] > out["SLA_Days"]).astype(float), np.nan
    )
    return out


def prepare(df_raw):
    """Full pipeline: clean + engineer. Returns (featured_df, log)."""
    clean, log = clean_data(df_raw)
    return add_features(clean), log


def labeled_subset(df):
    """Completed requests with a known target only (open/cancelled excluded)."""
    sub = df[df[TARGET].notna()].copy()
    sub[TARGET] = sub[TARGET].astype(int)
    return sub


def split_data(df_labeled):
    """80/20 split, random_state=42, as required by the midterm."""
    X = df_labeled[FEATURES]
    y = df_labeled[TARGET]
    return train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
