# Updated Requirements, Use Cases and Decision-Support Workflow

(Numbers in the evidence come from the bundled synthetic sample; the System Design page recomputes them from whatever dataset is loaded. Replace with your own midterm numbers.)

## Functional requirements (each maps to an implemented page)
| # | Requirement | Evidence | Implemented in |
|---|---|---|---|
| FR1 | The system shall display overall SLA breach rate and request volume. | Overall breach rate 67.2% across 351 completed requests. | Dashboard (KPIs) |
| FR2 | The system shall report breach rate per office. | Registrar highest at 81.9%. | Data Analysis, Dashboard |
| FR3 | The system shall flag open requests with long queues. | High-queue breach rate 96.7% vs 45.8% for Low. | Dashboard (review queue) |
| FR4 | The system shall warn staff when required documents are incomplete. | Queue_Length and incomplete documents are the two strongest model features. | Prediction, Dashboard |
| FR5 | The system shall predict breach risk at submission and route high-risk requests to human review. | Recall 0.73, accuracy 0.72 vs majority baseline 0.68. | Prediction, Dashboard |

## Non-functional requirements
1. Performance: the model is loaded once with `@st.cache_resource`; predictions take under 2 seconds.
2. Privacy and security: only synthetic or authorized data is deployed; no credentials or real student records in the repository.
3. Transparency and usability: every prediction shows model version, timestamp, limitations and a human-review notice.

## Actors
- Student / Requester: submits requests; cannot view analytics or predictions.
- Student Services Staff: views results, reviews flagged requests, records the final decision.
- Administrator: views SLA performance and workload; does not record case decisions.

## Diagrams
- Updated use case diagram: `assets/use_case_diagram.png` (new use cases in green: Upload & Validate Dataset, View SLA Performance, Review Delay Risk, Record Final Decision).
- Decision-support workflow: `assets/decision_workflow.png`.
