# VII. Test and Acceptance Checklist

Status key: [x] verified in my build/tests, [ ] you must do or confirm after deploying.

- [ ] Deployed URL opens without an error. *(Do after deploying; check Streamlit logs if the build fails.)*
- [ ] All five modules work; no placeholder text remains. *(Code has no placeholders; click through every page on the deployed app.)*
- [ ] CSV upload validates schema and handles invalid files. *(Implemented: empty file, non-CSV, missing columns, extra columns, no completed rows. Test each one in the app.)*
- [x] Predictions match midterm results on the same test cases. *(Notebook and app give the same confusion matrix [[16,7],[13,35]] and metrics on the 80/20 split, random_state=42; the Prediction page also has a "Run consistency check" button.)*
- [x] No test labels or future-only fields leak into inference. *(`FEATURES` in `modules/data_processing.py` contains only submission-time fields; Processing_Days, Status, Reopened, Satisfaction_Score are excluded.)*
- [x] Model version, prediction timestamp, limitations, and human review are visible. *(Prediction page shows all four.)*
- [x] Use case diagram and requirements correspond to implemented features. *(See docs/REQUIREMENTS.md: each requirement maps to a page.)*

## Test log (fill in as you test the deployed app)
| Test | Expected | Result (Pass/Fail) | Screenshot |
|---|---|---|---|
| Upload valid CSV | Preview, null/duplicate summary, cleaning log | | |
| Upload CSV with a missing column | Red error naming the missing column | | |
| Upload empty CSV | Error "no rows" | | |
| Upload non-CSV text file | Error "could not read" | | |
| Valid prediction input | Class, probability, risk, timestamp | | |
| Queue length 0 / very high | Still predicts, no crash | | |
| Charts on Data Analysis page | 5 interactive charts render | | |
| Dashboard as Student role | Access denied message | | |
| Record decision as Staff | Decision appears in log + CSV download | | |
