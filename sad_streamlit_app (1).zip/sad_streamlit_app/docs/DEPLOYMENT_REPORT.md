# Short Deployment Report - Section B (SLA Breach Prediction)

**Name:** ______________________  **Section:** B
**GitHub repository:** ______________________
**Deployed Streamlit URL:** ______________________

## 1. Reused code (from the midterm)
Same dataset schema, cleaning rules, engineered features (Submission_Weekday, Queue_Category), target definition (SLA_Breached = Processing_Days > SLA_Days for completed requests), Decision Tree in a OneHotEncoder + passthrough pipeline, 80/20 split with random_state=42, and the same evaluation metrics (positive class = 1).

## 2. Changes made for deployment
- Prediction checkpoint fixed at request submission; leakage variables (Processing_Days, Status, Reopened, Satisfaction_Score) are never used in inference.
- Fitted pipeline saved once with joblib and loaded with @st.cache_resource (no retraining on refresh).
- Added metadata (model version, training time, metrics, feature importance) for display in the app.
- Added CSV validation, interactive Plotly charts, risk/review queue, human decision log, and SAD pages.

## 3. Results (replace with your own if your data differs)
Test set (n=71): accuracy 0.72, precision 0.83, recall 0.73, F1 0.78; majority baseline accuracy 0.68. Top features: Queue_Length, Required_Documents_Complete, Assigned_Office.

## 4. Five sample predictions
| Service | Requester | Channel | Priority | Office | Docs complete | Queue | SLA days | Prediction | Probability | Risk |
|---|---|---|---|---|---|---|---|---|---|---|
| Records | Student | Portal | High | Registrar | No | 22 | 5 | Breach | 100% | High |
| IT Support | Staff | Email | Normal | IT Office | Yes | 4 | 2 | Breach | 69% | Medium |
| Scholarship Inquiry | Student | Walk-in | Low | Scholarship Office | Yes | 6 | 7 | Within SLA | 0% | Low |
| Certification | Faculty | Portal | Normal | Registrar | No | 12 | 5 | Breach | 100% | High |
| Clearance | Student | Portal | Normal | Student Affairs | Yes | 9 | 4 | Within SLA | 38% | Low |

## 5. Tests performed
See docs/ACCEPTANCE_CHECKLIST.md (test log). Logic tests done: cleaning, features, training, prediction, scoring, and metric consistency between notebook and app. Fill in the UI test results after deploying.

## 6. Limitations
Small synthetic dataset; Decision Tree gives coarse probabilities; no information after submission is used; missing or inconsistent inputs reduce reliability; predictions support, but never replace, staff decisions.

## 7. Reflection
(Write 3-5 sentences in your own words: what was hardest, what you learned about moving a model into an information system, and how human review fits the workflow.)
