# VIII. Required Submission - what is ready and what you add

| # | Item | Status |
|---|---|---|
| 1 | GitHub repository URL and deployed Streamlit URL | YOU: push repo, deploy, paste URLs in docs/DEPLOYMENT_REPORT.md |
| 2 | Original midterm .ipynb and revised project files | Revised: notebooks/SectionB_Midterm_Revised.ipynb + project files. YOU: attach your original midterm notebook |
| 3 | Screenshots of five working modules and five sample predictions | YOU: take them on the deployed app (the five sample inputs are in docs/DEPLOYMENT_REPORT.md) |
| 4 | Updated requirements, use case diagram, decision-support workflow | Ready: docs/REQUIREMENTS.md, assets/use_case_diagram.png, assets/decision_workflow.png |
| 5 | Short deployment report | Draft ready: docs/DEPLOYMENT_REPORT.md. YOU: add URLs, test results, reflection |

Naming reminder from the midterm: SectionB_Lastname_Firstname_*.
